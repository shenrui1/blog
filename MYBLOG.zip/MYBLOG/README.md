node v14.17.1

npm install

#####目录简介
├── database                 // 数据集
├── dist
├── node_modules
├── src
│   ├── model                // MySQL
│   ├── public               // css，ts
│   ├── routes               // 路由
│   ├── views                // html
│   ├── app.ts               // 入口文件
├── package-lock.json
├── package.json
├── README.md
├── webpack.config.js